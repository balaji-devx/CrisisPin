package com.helios.crisispin.utils

import android.content.Context
import android.os.Build
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import android.speech.tts.TextToSpeech
import android.util.Log
import java.util.Locale

class AlertManager(context: Context) {

    // Always use applicationContext — avoids service/activity context leaks
    // and ensures vibrator is always accessible regardless of where we're called from
    private val appContext: Context = context.applicationContext

    private var tts: TextToSpeech? = null
    private var isTtsReady = false
    private var soundEnabled = true
    private var vibrationEnabled = true

    // Cooldown: AlertManager-level guard as backup in case service-level cooldown is bypassed
    private val lastAlertTime = mutableMapOf<String, Long>()
    private val cooldownMs = 5_000L // Tighter 5s backup cooldown here

    init {
        tts = TextToSpeech(appContext) { status ->
            if (status == TextToSpeech.SUCCESS) {
                val result = tts?.setLanguage(Locale.US)
                isTtsReady = result != TextToSpeech.LANG_MISSING_DATA &&
                        result != TextToSpeech.LANG_NOT_SUPPORTED
                Log.d("AlertManager", "TTS ready: $isTtsReady")
            } else {
                Log.e("AlertManager", "TTS init failed: $status")
            }
        }
    }

    fun setSoundEnabled(enabled: Boolean) {
        soundEnabled = enabled
        if (!enabled) tts?.stop()
    }

    fun setVibrationEnabled(enabled: Boolean) {
        vibrationEnabled = enabled
        if (!enabled) cancelVibration()
    }

    fun triggerAlert(
        message: String,
        playSound: Boolean = soundEnabled,
        doVibrate: Boolean = vibrationEnabled
    ) {
        val now = System.currentTimeMillis()
        if (now - (lastAlertTime[message] ?: 0L) < cooldownMs) {
            Log.d("AlertManager", "Backup cooldown hit for '$message'")
            return
        }
        lastAlertTime[message] = now
        Log.d("AlertManager", "Alert triggered: $message")

        if (doVibrate && vibrationEnabled) vibrate()
        if (playSound && soundEnabled) speak(message)
    }

    private fun getVibrator(): Vibrator? {
        return try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                // Android 12+ — use VibratorManager
                val vm = appContext.getSystemService(VibratorManager::class.java)
                vm?.defaultVibrator
            } else {
                // Android 11 and below — use Vibrator directly
                @Suppress("DEPRECATION")
                appContext.getSystemService(Vibrator::class.java)
            }
        } catch (e: Exception) {
            Log.e("AlertManager", "getVibrator failed: ${e.message}")
            null
        }
    }

    private fun vibrate() {
        val vibrator = getVibrator()

        if (vibrator == null) {
            Log.e("AlertManager", "Vibrator is null — cannot vibrate")
            return
        }

        if (!vibrator.hasVibrator()) {
            Log.e("AlertManager", "hasVibrator() = false")
            return
        }

        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                // Try waveform first (3 strong pulses)
                // timings and amplitudes MUST be same length — this was the bug before
                val timings    = longArrayOf(0, 400, 200, 400, 200, 400)
                val amplitudes = intArrayOf(  0, 255,   0, 255,   0, 255)
                // Both arrays length = 6 ✓

                val hasAmplitudeControl = vibrator.hasAmplitudeControl()

                if (hasAmplitudeControl) {
                    val effect = VibrationEffect.createWaveform(timings, amplitudes, -1)
                    vibrator.vibrate(effect)
                    Log.d("AlertManager", "Waveform vibration triggered")
                } else {
                    // Device doesn't support amplitude — use simple one-shot
                    // createOneShot is the most compatible fallback
                    val effect = VibrationEffect.createOneShot(600, VibrationEffect.DEFAULT_AMPLITUDE)
                    vibrator.vibrate(effect)
                    Log.d("AlertManager", "OneShot vibration triggered (no amplitude control)")
                }
            } else {
                // Android 7 and below — use deprecated long[] pattern
                @Suppress("DEPRECATION")
                vibrator.vibrate(longArrayOf(0, 400, 200, 400, 200, 400), -1)
                Log.d("AlertManager", "Legacy vibration triggered")
            }
        } catch (e: SecurityException) {
            // This means VIBRATE permission is missing from manifest
            Log.e("AlertManager", "VIBRATE permission missing! Add to AndroidManifest.xml: ${e.message}")
        } catch (e: Exception) {
            Log.e("AlertManager", "Vibration exception: ${e.message}")
        }
    }

    private fun cancelVibration() {
        try { getVibrator()?.cancel() } catch (e: Exception) { }
    }

    private fun speak(message: String) {
        if (!isTtsReady) {
            Log.e("AlertManager", "TTS not ready")
            return
        }
        val text = when (message.uppercase()) {
            "SOS"   -> "Emergency! S O S alert received. Someone nearby needs help!"
            "FIRE"  -> "Warning! Fire alert received. There is a fire nearby!"
            "MED"   -> "Medical emergency! Someone nearby needs medical attention!"
            "PANIC" -> "Alert! Someone nearby is in danger!"
            "HELP"  -> "Attention! Someone nearby needs assistance!"
            else    -> "Emergency alert received."
        }
        tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "crisispin_alert")
        Log.d("AlertManager", "TTS speaking: $text")
    }

    fun release() {
        try {
            tts?.stop()
            tts?.shutdown()
        } catch (e: Exception) { }
        tts = null
    }
}